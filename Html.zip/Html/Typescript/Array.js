var n = 2;
var f = [1, 2, 3, 4, 'a', true];
var m;
m = [1, 2, 3, 4];
for (var i in m) {
    console.log(i);
}
m.push(5);
n = m.pop();
for (var j in m) {
    console.log(j);
}
var nl = [1, 2, 3];
var numlist = [1, 2, 3];
