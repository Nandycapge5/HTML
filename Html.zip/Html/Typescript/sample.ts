var a:number=12;
var b:number;
var c:String;
var d:boolean;
var e=undefined;
var f=null;

a=10;
b=20;
c="welcome";
d=false;
e="hi";
console.log(a+b);
console.log(e);