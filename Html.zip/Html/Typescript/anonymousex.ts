function addition(x:number,y:number):number
{
    return x+y;
}
let s=function(x:number,y:number):number{
    return x+y;
};
addition(10,20);
s(2,4);
let s1=(x:number,y:number)=>x+y;
s1(3,4);
let s2=(x:number,y:number)=>{return x+y};
s2(5,5);
let s3=()=>console.log("function without return type");
s3();