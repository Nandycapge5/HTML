function add12(x:string,y:string,z:string ):string;
function add12(x:number,y:number,z:number ):number;


function add12(x:any,y:any,z:any):any
{
let result:any;
if(typeof x=="number" &&typeof y=="number"&&typeof z=="number")
{
    result =x+y+z;
}
else{
    result =x+""+y+""+z;
}
return result;
}
let res1=add12(3,3,4);
let res2=add12("welcome","to","capgemini");
console.log(res1);
console.log(res2);