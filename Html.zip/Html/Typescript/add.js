function add(a, b, c) {
    return a + b + c;
}
var sum = add(10, 20);
var sum2 = add(10, 20, 30);
var sum1 = add('welcome', 30);
console.log(sum);
console.log(sum1);
console.log(sum2);
//var x:number;
function add1(a, b, c) {
    return a + b + c;
}
var sum3 = add1(100, 200, 200);
var sum4 = add1(1, 2, 3);
console.log(sum3);
