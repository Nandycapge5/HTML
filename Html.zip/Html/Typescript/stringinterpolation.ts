let firstname:string="International Business";
let site:string="www.cit.edu.in";


//string concatenation
let str='Hello,my name is '+firstname+'and my site'+site;
console.log(str);

//string interpolation and multiple line
let str1=`hello,my name is ${firstname} and
 my site is ${site}`;
console.log(str1);

