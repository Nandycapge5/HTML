export class Person{
    private fname:string;
     private  lname:string;
     constructor(fname:string,lname:string)
     {
         this.fname=fname;
         this.lname=lname;
  
     }
     fullName():string{
         return this.fname+""+this.lname;
     }
  }
  export class Employee 
  {
      id:number;
      constructor(id:number,fname:string,lname:string)
      {
          super(fname,lname);
          this.id=id;
      }
          showDetails():void
          {
              console.log(this.id+"  "+this.fullName());
          }
      }
          let e1=new Employee(1,"nandhini ","pooja");
          e1.showDetails();
      
  