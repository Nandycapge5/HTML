"use strict";
exports.__esModule = true;
var Person = /** @class */ (function () {
    function Person(fname, lname) {
        this.fname = fname;
        this.lname = lname;
    }
    Person.prototype.fullName = function () {
        return this.fname + "" + this.lname;
    };
    return Person;
}());
exports.Person = Person;
var Employee = /** @class */ (function () {
    function Employee(id, fname, lname) {
        _this = _super.call(this, fname, lname) || this;
        this.id = id;
    }
    Employee.prototype.showDetails = function () {
        console.log(this.id + "  " + this.fullName());
    };
    return Employee;
}());
exports.Employee = Employee;
var e1 = new Employee(1, "nandhini ", "pooja");
e1.showDetails();
