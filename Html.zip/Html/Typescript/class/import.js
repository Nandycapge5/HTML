"use strict";
exports.__esModule = true;
var export_1 = require("./export");
var s = new export_1.Employee(1, "nandy", "pooja");
var r = s.showDetails();
console.log("Person Details:" + r);
var p = new export_1.Employee(2, "sam", "menaka");
var t = p.showDetails();
console.log("Person Details:" + t);
