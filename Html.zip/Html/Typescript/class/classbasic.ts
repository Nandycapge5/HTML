class Person{
    firstname:string;
    lastname:string;
}
var p=new Person();
p.firstname="nandy";
p.lastname="sam";
console.log(p.firstname+p.lastname);
