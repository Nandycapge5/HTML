import {Person,Employee} from "./export";
let s=new Employee(1,"nandy","pooja");
let r=s.showDetails();
console.log("Person Details:"+r);



let p=new Employee(2,"sam","menaka");
let t=p.showDetails();
console.log("Person Details:"+t);