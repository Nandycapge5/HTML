class Employee
{
    static empid;number;
    name:string;
    constructor(empid:number,name:string)
    {
        Employee.empid=empid;
        this.name=name;

    }
    displayDetails()
    {
        return Employee.empid+":"+this.name;
    }
}    
   //mployee.empid=1234;
    var emp=new Employee(12,"nandy");
    console.log(emp.displayDetails());
    

