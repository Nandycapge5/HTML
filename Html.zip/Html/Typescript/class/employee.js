var Employee = /** @class */ (function () {
    function Employee(empid, name) {
        Employee.empid = empid;
        this.name = name;
    }
    Employee.prototype.displayDetails = function () {
        return Employee.empid + ":" + this.name;
    };
    return Employee;
}());
//mployee.empid=1234;
var emp = new Employee(12, "nandy");
console.log(emp.displayDetails());
