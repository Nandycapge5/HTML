function f2() {
    var a = 120;
    if (a > 100) {
        var b = 20;
        console.log(a);
    }
    console.log(b);
}
f2();
