function addition(x, y) {
    return x + y;
}
var s = function (x, y) {
    return x + y;
};
addition(10, 20);
s(2, 4);
var s1 = function (x, y) { return x + y; };
s1(3, 4);
var s2 = function (x, y) { return x + y; };
s2(5, 5);
var s3 = function () { return console.log("function without return type"); };
s3();
