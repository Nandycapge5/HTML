var firstname = "International Business";
var site = "www.cit.edu.in";
//string concatenation
var str = 'Hello,my name is ' + firstname + 'and my site' + site;
console.log(str);
//string interpolation and multiple line
var str1 = "hello,my name is " + firstname + " and\n my site is " + site;
console.log(str1);
