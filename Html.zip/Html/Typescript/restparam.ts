function add142(x:number,... y:number[] ):number
{
let resu=x;
for(var i=0;i<y.length;i++)
{
    resu +=y[i];
}
return resu;
}
let g=add142(2,6);
let t=add142(3,2,1,4);
console.log(g);
console.log(t);