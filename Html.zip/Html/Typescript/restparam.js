function add142(x) {
    var y = [];
    for (var _i = 1; _i < arguments.length; _i++) {
        y[_i - 1] = arguments[_i];
    }
    var resu = x;
    for (var i = 0; i < y.length; i++) {
        resu += y[i];
    }
    return resu;
}
var g = add142(2, 6);
var t = add142(3, 2, 1, 4);
console.log(g);
console.log(t);
