function add12(x, y, z) {
    var result;
    if (typeof x == "number" && typeof y == "number" && typeof z == "number") {
        result = x + y + z;
    }
    else {
        result = x + "" + y + "" + z;
    }
    return result;
}
var res1 = add12(3, 3, 4);
var res2 = add12("welcome", "to", "capgemini");
console.log(res1);
console.log(res2);
