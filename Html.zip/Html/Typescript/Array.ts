let n=2;
let f=[1,2,3,4,'a',true];
var m:number[];
m=[1,2,3,4];
for(let i in m)
{
    console.log(i);
    
}
m.push(5);
n=m.pop();
for(let m in j)
{
    console.log(j);
}
let nl:number[]=[1,2,3];
let numlist:Array<number>=[1,2,3];